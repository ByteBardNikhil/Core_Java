package com.backend.Pill_Pick;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PillPickApplicationTests {

	@Test
	void contextLoads() {
	}

}
