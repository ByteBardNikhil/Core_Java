package com.backend.Pill_Pick;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PillPickApplication {

	public static void main(String[] args) {
		SpringApplication.run(PillPickApplication.class, args);
	}

}
